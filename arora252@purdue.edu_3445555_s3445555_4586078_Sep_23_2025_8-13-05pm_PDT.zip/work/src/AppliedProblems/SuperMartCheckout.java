package AppliedProblems;

import CommonUtils.BetterQueue;

public class SuperMartCheckout implements SuperMartCheckoutInterface {
    /**
     * Array of all available customers
     */
    public Customer[] customers;
    /**
     * Array of all available queues that customers can line up on
     */
    public BetterQueue<Customer>[] queues;
    /**
     * Array of all cashiers available to work
     */
    public Cashier[] cashiers;

    /**
     * Time counter for simulation
     */
    public int time;

    /**
     * Constructor for a Checkout object that's in charge of simulation.
     * @param customers: all customers to serve, sorted by arrival time
     * @param cashiers: all available cashiers
     * @param numQueues: number of available queues to put customers in
     */
    public SuperMartCheckout(Customer[] customers, Cashier[] cashiers, int numQueues) {
        // todo
    }

    /**
     * Simulate putting all customers that arrive at the current time into queues.
     * @implNote  Assign customers to queue using round-robin.
     */
    @Override
    public void assignToQueues() {
        // todo
    }

    /**
     * Simulate dispatching customers to cashiers at the current time.
     *
     * @implNote At the current time, for each available cashier, match it with the customer that can be finished the earliest
     * If there are ties, choose the customer from the queue with the lowest index.
     */
    @Override
    public void dispatchCustomers() {
        // todo
    }

    /**
     * Simulate the whole checkout process for all customers
     * @implNote Simulate through each unit of time using the provided helper functions.
     */
    @Override
    public void run() {
        // todo
    }

    /**
     * Return statistical information about customer's wait times.
     * @implNote Can be utilized to calculate and update utilization of each cashier as well.
     * @return double array with 0 index representing the average wait time of each customer and 1 index representing the max wait time of a customer.
     */

    @Override
    public Double[] report() {
        // todo
        return null;
    }

}
