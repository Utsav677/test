package AppliedProblems;

import java.util.ArrayList;

/**
 * Interface for the Math Expression Evaluator.
 * The implementing class should follow the specifications as mentioned in the handout
 *
 * You may only use java.util.ArrayList, java.util.List, and java.io.* from the standard library.
 * Any other containers used must be ones you created.
 */

public interface MathExpressionEvaluatorInterface {
    public class EvaluatorResult {
        long key;
        public EvaluatorResult(long key) {
            this.key = key;
        }
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            EvaluatorResult that = (EvaluatorResult) o;
            return this.key == that.key;
        }
        @Override
        public String toString() {
            return Long.toString(this.key);
        }
    }
    ArrayList<EvaluatorResult> getExpressionResults(String filename);
}
