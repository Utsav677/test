package AppliedProblems;

import CommonUtils.BetterStack;

import java.io.*;
import java.util.ArrayList;

public class MathExpressionEvaluator implements MathExpressionEvaluatorInterface {

    /**
     * Evaluate multiple expressions from the file.
     * @param filename
     * @return An array list of results of each expression in the file
     */
    @Override
    public ArrayList<EvaluatorResult> getExpressionResults(String filename) {
        ArrayList<EvaluatorResult> keys = new ArrayList<>();
        try {
            BufferedReader bf = new BufferedReader(new FileReader(filename));
            // todo
        } catch (IOException e) {
            System.err.println("Test file (\"" + filename + "\"): " + e.getMessage());
        }
        return keys;
    }
}
