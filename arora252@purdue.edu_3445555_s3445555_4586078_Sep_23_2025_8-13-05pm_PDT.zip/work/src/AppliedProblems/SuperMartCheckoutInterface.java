package AppliedProblems;

public interface SuperMartCheckoutInterface {
    public class Customer {
        private int cid;
        private int arrivalTime;
        private int numItems;
        private int startTime;
        private int finishTime;
        private int queueIndex;
        private int cashierId;

        public Customer(int cid, int arrivalTime, int numItems) {
            this.cid = cid;
            this.arrivalTime = arrivalTime;
            this.numItems = numItems;
            this.cashierId = -1;
            this.queueIndex = -1;
            this.startTime = -1;
            this.finishTime = -1;
        }

        public int getCid() {
            return cid;
        }

        public int getArrivalTime() {
            return arrivalTime;
        }

        public int getNumItems() {
            return numItems;
        }

        public int getStartTime() {
            return startTime;
        }

        public int getFinishTime() {
            return finishTime;
        }

        public int getQueueIndex() {
            return queueIndex;
        }

        public int getCashierId() {
            return cashierId;
        }

        public void setCid(int cid) {
            this.cid = cid;
        }

        public void setArrivalTime(int arrivalTime) {
            this.arrivalTime = arrivalTime;
        }

        public void setNumItems(int numItems) {
            this.numItems = numItems;
        }

        public void setStartTime(int startTime) {
            this.startTime = startTime;
        }

        public void setFinishTime(int finishTime) {
            this.finishTime = finishTime;
        }

        public void setQueueIndex(int queueIndex) {
            this.queueIndex = queueIndex;
        }

        public void setCashierId(int cashierId) {
            this.cashierId = cashierId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Customer customer = (Customer) o;
            return cid == customer.cid && arrivalTime == customer.arrivalTime && numItems == customer.numItems && startTime == customer.startTime && finishTime == customer.finishTime && queueIndex == customer.queueIndex && cashierId == customer.cashierId;
        }

        @Override
        public String toString() {
            return "Customer{" +
                    "cid=" + cid +
                    ", arrivalTime=" + arrivalTime +
                    ", numItems=" + numItems +
                    ", startTime=" + startTime +
                    ", finishTime=" + finishTime +
                    ", queueIndex=" + queueIndex +
                    ", cashierId=" + cashierId +
                    '}';
        }
    }
    public class Cashier {
        private int cid;
        private int scanTime;
        private int nextFreeTime;
        private int totalWorkTime;
        private double util;

        public Cashier(int cid, int scanTime) {
            this.cid = cid;
            this.scanTime = scanTime;
            this.nextFreeTime = 0;
            this.totalWorkTime = 0;
            this.util = 0;
        }

        /**
         * Check if the cashier can serve a new customer
         * @param currentTime
         * @return true if the cashier can serve a customer at currentTime
         */

        public boolean canServe(int currentTime) {
            return this.nextFreeTime <= currentTime;
        }

        /**
         * Estimate the next time that the cashier will be free again.
         * @implNote It's assumed that once a customer finishes helping one customer, they can start helping the next one right away within the same time unit.
         * @param currentTime
         * @param numItems
         * @return next time that the cashier can start working again.
         */
        public int estimateFinish(int currentTime, int numItems) {
            return Math.max(currentTime, this.nextFreeTime) + numItems * this.scanTime;
        }

        public int getCid() {
            return cid;
        }

        public void setCid(int cid) {
            this.cid = cid;
        }

        public int getScanTime() {
            return scanTime;
        }

        public void setScanTime(int scanTime) {
            this.scanTime = scanTime;
        }

        public int getNextFreeTime() {
            return nextFreeTime;
        }

        public void setNextFreeTime(int nextFreeTime) {
            this.nextFreeTime = nextFreeTime;
        }

        public int getTotalWorkTime() {
            return totalWorkTime;
        }

        public void setTotalWorkTime(int totalWorkTime) {
            this.totalWorkTime = totalWorkTime;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Cashier cashier = (Cashier) o;
            return cid == cashier.cid && scanTime == cashier.scanTime && Math.abs(util - cashier.util) <= 1e-10;
        }

        @Override
        public String toString() {
            return "Cashier{" +
                    "cid=" + cid +
                    ", scanTime=" + scanTime +
                    ", nextFreeTime=" + nextFreeTime +
                    ", totalWorkTime=" + totalWorkTime +
                    ", util=" + util +
                    '}';
        }

        public double getUtil() {
            return util;
        }

        public void setUtil(double util) {
            this.util = util;
        }
    }
    /**
     * Simulate putting all customers that arrive at the current time into queues.
     * @implNote  Assign customers to queue using round-robin.
     */
    void assignToQueues();
    /**
     * Simulate dispatching customers to cashiers at the current time.
     *
     * @implNote At the current time, for each available cashier, match it with the customer that can be finished the earliest
     * If there are ties, choose the customer from the queue with the lowest index.
     */

    void dispatchCustomers();

    /**
     * Simulate the whole checkout process for all customers
     * @implNote Simulate through each unit of time using the provided helper functions.
     */
    void run();

    /**
     * Return statistical information about customer's wait times.
     * @implNote Can be utilized to calculate and update utilization of each cashier as well.
     * @return double array with 0 index representing the average wait time of each customer and 1 index representing the max wait time of a customer.
     */
    Double[] report();
}
