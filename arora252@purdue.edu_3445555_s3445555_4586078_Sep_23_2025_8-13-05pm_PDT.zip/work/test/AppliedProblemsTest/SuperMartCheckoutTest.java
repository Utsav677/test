package AppliedProblemsTest;

import AppliedProblems.SuperMartCheckoutInterface.Customer;
import AppliedProblems.SuperMartCheckoutInterface.Cashier;
import AppliedProblems.SuperMartCheckout;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Named;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.params.provider.Arguments.arguments;

/**
 * Tests SuperMartCheckout extensively
 */
@Timeout(value = 10000, unit = TimeUnit.MILLISECONDS)
public class SuperMartCheckoutTest {
    final static String prefix = "./test/AppliedProblemsTest/superMartCheckoutFiles/";
    final static File[] folderPaths = {new File(prefix + "sample"),
            new File(prefix + "manual")};
    final static String inputSuffix = "in", ansSuffix = "out";

    /**
     * All done in one instance of the SuperMartCheckout
     */

    /**
     * Provides a list of test files and their names for the parameterized test below.
     *
     * @return List of valid test input files and their names
     */
    static Stream<Arguments> testFileProvider() {
        ArrayList<Arguments> args = new ArrayList<>();
        //for all folders provided
        for (final File path : folderPaths) {
            //for each file in each folder
            for (final File entry : Objects.requireNonNull(path.listFiles())) {
                String inputFile = entry.getPath();
                //if not an input file, skip
                if (!(inputFile.substring(inputFile.length() - inputSuffix.length()).equalsIgnoreCase(inputSuffix))) {
                    continue;
                }
                args.add(arguments(Named.of(entry.getName(), entry)));
            }
        }

        return args.stream();
    }

    /**
     * Convert input file into a valid SuperMartCheckout object
     * @param filename
     * @return SuperMartCheckout Object
     */

    SuperMartCheckout readInput(String filename) {
        try {
            BufferedReader bf = new BufferedReader(new FileReader(filename));
            String[] firstLine = bf.readLine().split(" ");
            int customerCount = Integer.parseInt(firstLine[0]);
            int cashierCount = Integer.parseInt(firstLine[1]);
            int numberOfQueues = Integer.parseInt(firstLine[2]);
            Customer[] customers = new Customer[customerCount];
            Cashier[] cashiers = new Cashier[cashierCount];

            for (int i = 0; i < customerCount; i++) {
                String[] line = bf.readLine().split(" ");
                int cid = Integer.parseInt(line[0]);
                int arrivalTime = Integer.parseInt(line[1]);
                int numItems = Integer.parseInt(line[2]);
                customers[i] = new Customer(cid, arrivalTime, numItems);
            }

            for (int i = 0; i < cashierCount; i++) {
                String[] line = bf.readLine().split(" ");
                int cid = Integer.parseInt(line[0]);
                int scanTime = Integer.parseInt(line[1]);
                cashiers[i] = new Cashier(cid, scanTime);
            }

            return new SuperMartCheckout(customers, cashiers, numberOfQueues);
        } catch (IOException e) {
            System.err.println("Test file (\"" + filename + "\"): " + e.getMessage());
        }
        return null;
    }

    /**
     * Runs all input files
     */
    @DisplayName("File-based tests for SuperMarketCheckout")
    @ParameterizedTest(name = "{index}: {0}")
    @MethodSource("testFileProvider")
    void runFiles(File file) {
        String inputFile = file.getPath();

        //guaranteed to have a valid input file
        String ansFile = inputFile.substring(0, inputFile.length() - inputSuffix.length()) + ansSuffix;

        //run test
        Double[] report = null;
        SuperMartCheckout checkout = readInput(inputFile);
        try {
            checkout.run();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Error calling checkout.run() for file: \"" + file.getName() + "\"\nError:\n" + e.getMessage());
        }

        try {
            report = checkout.report();
        } catch (Exception e) {
            e.printStackTrace();
            fail("Error calling checkout.report() for file: \"" + file.getName() + "\"\nError:\n" + e.getMessage());
        }

        //compare to answer
        //read in answer file
        BufferedReader bf = null;
        Customer[] customers = new Customer[checkout.customers.length];
        Cashier[] cashiers = new Cashier[checkout.cashiers.length];
        Double[] trueReport = new Double[2];
        try {
            bf = new BufferedReader(new FileReader(ansFile));
            for (int i = 0; i < customers.length; i++) {
                String[] line = bf.readLine().split(" ");
                int cid = Integer.parseInt(line[0]);
                int arrivalTime = Integer.parseInt(line[1]);
                int queueIndex = Integer.parseInt(line[2]);
                int cashierId = Integer.parseInt(line[3]);
                int startTime = Integer.parseInt(line[4]);
                int finishTime = Integer.parseInt(line[5]);
                int numItems = Integer.parseInt(line[6]);
                customers[i] = new Customer(cid, arrivalTime, numItems);
                customers[i].setQueueIndex(queueIndex);
                customers[i].setCashierId(cashierId);
                customers[i].setStartTime(startTime);
                customers[i].setFinishTime(finishTime);
            }
            for (int i = 0; i < cashiers.length; i++) {
                String[] line = bf.readLine().split(" ");
                int cid = Integer.parseInt(line[0]);
                int scanTime = Integer.parseInt(line[1]);
                double util = Double.parseDouble(line[2]);
                cashiers[i] = new Cashier(cid, scanTime);
                cashiers[i].setUtil(util);
            }
            String[] line = bf.readLine().split(" ");
            trueReport[0] = Double.parseDouble(line[0]);
            trueReport[1] = Double.parseDouble(line[1]);
        } catch (FileNotFoundException e) {
            fail("GRADER ERROR:: ANSWER FILE NOT FOUND:: \"" + file.getName() + "\"");
        } catch (IOException e) {
            fail("GRADER ERROR:: IO ERROR WITH ANSWER FILE:: \"" + file.getName() + "\"");
        }

        //written out explicitly for clarity for future readers of this code
        //compare

        compareAnswer(customers, checkout.customers, "Test case: " + inputFile);
        compareAnswer(cashiers, checkout.cashiers, "Test case: " + inputFile);
        compareAnswer(trueReport, report, "Test case: " + inputFile);
    }

    /**
     * Compares answer and prints detailed information if wrong
     *
     * @param trueAns  correct answer
     * @param ans      actual answer
     * @param testName name of test, to print if failed
     */
    private static <T> void compareAnswer(T[] trueAns, T[] ans, String testName) {
        TestUtils.compareArraysWithEqual(trueAns, ans, testName);
    }
}
