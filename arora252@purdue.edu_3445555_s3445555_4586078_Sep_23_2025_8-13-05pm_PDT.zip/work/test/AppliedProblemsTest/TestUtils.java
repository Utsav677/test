package AppliedProblemsTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.fail;

/**
 * Stores a few useful functions not provided in the testing APIs used.
 */
public class TestUtils {
    /**
     * Compares two arrays.  Requires implementation of .equals and .toString on the object for it to make sense
     * @param trueAns correct answer
     * @param ans calculated answer
     * @param testName test name for error reporting
     */
    public static void compareArraysWithEqual(List<?> trueAns, List<?> ans, String testName) {
        String failurePrefix = "Test case \"" + testName + "\":: ";
        if(trueAns.size() != ans.size()){
            fail(failurePrefix + "Incorrect size, expected " + trueAns.size() + ", actual is " + ans.size());
        }

        for(int i=0; i<trueAns.size(); i++){
            if(! trueAns.get(i).equals(ans.get(i))){
                fail(failurePrefix + "\nIncorrect element at line " + (i+1)
                        + ",\n expected \"" + trueAns.get(i).toString() + "\",\n actual is \""
                        + ans.get(i) + "\"");
            }
        }
    }

    public static <T> void compareArraysWithEqual(T[] trueAns, T[] ans, String testName) {
        String failurePrefix = "Test case \"" + testName + "\":: ";
        if(trueAns.length != ans.length){
            fail(failurePrefix + "Incorrect size, expected " + trueAns.length + ", actual is " + ans.length);
        }

        boolean toleranceCompare = false;

        if (trueAns instanceof Double[]) {
            toleranceCompare = true;
        }

        for(int i=0; i<trueAns.length; i++){
            boolean condition = false;
            if (toleranceCompare) {
                double one = (Double)trueAns[i];
                double two = (Double)ans[i];
                condition = Math.abs(one - two) > 1e-10;
            } else {
                condition = !trueAns[i].equals(ans[i]);
            }
            if(condition){
                fail(failurePrefix + "\nIncorrect element at line " + (i+1)
                        + ",\n expected \"" + trueAns[i].toString() + "\",\n actual is \""
                        + ans[i] + "\"");
            }
        }
    }
}
